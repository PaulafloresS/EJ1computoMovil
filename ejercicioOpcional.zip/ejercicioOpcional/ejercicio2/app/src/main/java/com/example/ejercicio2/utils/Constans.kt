package com.example.ejercicio2.utils
object Constans{
    const val BASE_URL = "https://hp-api.onrender.com/"
    const val LOGTAG ="LOGS"
}
